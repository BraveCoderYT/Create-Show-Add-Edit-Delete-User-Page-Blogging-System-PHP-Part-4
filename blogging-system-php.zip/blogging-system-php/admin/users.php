<?php include 'includes/header.php'; ?>

<?php
  if ($_SESSION['__ROLE__'] == 0) {
    echo "<script>window.location.replace('index.php');</script>";
  }
?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Users</h1>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">All Users</h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
              <?php
                $sql = "SELECT * FROM users";
                $result = mysqli_query($conn, $sql);

                if (mysqli_num_rows($result) > 0) {
              ?>
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                          <th>Id</th>
                          <th>Name</th>
                          <th>Email</th>
                          <th>Role</th>
                          <th>Action</th>
                        </tr>
                    </tfoot>
                    <tbody>
                      <?php $uid = 0; while ($row = mysqli_fetch_assoc($result)) { $uid++ ?>
                        <tr>
                            <td><?php echo $uid; ?></td>
                            <td><?php echo $row['first_name'] . " " . $row['last_name']; ?></td>
                            <td><?php echo $row['email']; ?></td>
                            <td><?php
                              if ($row['role'] == 1) {
                                echo "Admin";
                              }else {
                                echo "User";
                              }
                            ?></td>
                            <td><a href="edit-user.php?index=<?php echo $row['id']; ?>">Edit</a> <a href="delete-user.php?index=<?php echo $row['id']; ?>" class="text-danger ml-1">Delete</a></td>
                        </tr>
                      <?php } ?>
                    </tbody>
                </table>
              <?php } ?>
            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<?php include 'includes/footer.php'; ?>

<!-- Page level plugins -->
<script src="vendor/datatables/jquery.dataTables.min.js"></script>
<script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

<!-- Page level custom scripts -->
<script src="js/demo/datatables-demo.js"></script>
