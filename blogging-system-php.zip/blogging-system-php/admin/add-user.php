<?php include 'includes/header.php'; ?>

<?php
  if ($_SESSION['__ROLE__'] == 0) {
    echo "<script>window.location.replace('index.php');</script>";
  }

  if (isset($_POST['submit'])) {
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $email = $_POST['email'];
    $password = md5($_POST['password']);
    $repeat_password = md5($_POST['repeat_password']);
    $role = $_POST['role'];

    if (mysqli_num_rows(mysqli_query($conn, "SELECT * FROM users WHERE email='$email'")) > 0) {
      $msg = "<div class='alert alert-warning'>{$email} - This Email is Already Taken.</div>";
    }else {
      if ($password === $repeat_password) {
        $sql = "INSERT INTO users (first_name, last_name, email, password, repeat_password, role) VALUES ('$first_name', '$last_name', '$email', '$password', '$repeat_password', '$role')";
        $result = mysqli_query($conn, $sql);

        if ($result) {
          $msg = "<div class='alert alert-success'>New User Added Successfull.</div>";
        }else {
          echo "Error: " . $sql . mysqli_error($conn);
        }
      }else {
        $msg = "<div class='alert alert-danger'>Password not Match.</div>";
      }
    }
  }
?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800">Add User</h1>
    <?php if (isset($_POST['submit'])) { echo $msg; } ?>

    <form class="form" action="" method="post">
      <div class="row">
        <div class="form-group col-lg-6 col-sm-12 mb-2">
          <input type="text" name="first_name" class="form-control" placeholder="First Name" required>
        </div>
        <div class="form-group col-lg-6 col-sm-12 mb-2">
          <input type="text" name="last_name" class="form-control" placeholder="Last Name" required>
        </div>
      </div>
      <div class="row">
        <div class="form-group col-sm-12 mb-2">
          <input type="email" name="email" class="form-control" placeholder="Email" required>
        </div>
      </div>
      <div class="row">
        <div class="form-group col-lg-6 col-sm-12 mb-2">
          <input type="password" name="password" class="form-control" placeholder="Password" required>
        </div>
        <div class="form-group col-lg-6 col-sm-12 mb-2">
          <input type="password" name="repeat_password" class="form-control" placeholder="Repeat Password" required>
        </div>
      </div>
      <div class="row">
        <div class="form-group col-sm-12 mb-2">
          <select class="form-control" name="role" required>
            <option value="" selected disabled>Select Role</option>
            <option value="1">Admin</option>
            <option value="0">User</option>
          </select>
        </div>
      </div>
      <div class="row">
        <div class="col-sm-12">
          <button type="submit" name="submit" class="btn btn-primary">Add User</button>
        </div>
      </div>
    </form>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<?php include 'includes/footer.php'; ?>
