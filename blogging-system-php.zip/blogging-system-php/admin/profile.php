<?php
  include 'includes/header.php';
  $id = $_SESSION['__ID__'];

  if (isset($_POST['submit'])) {
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];

    $sql = "UPDATE users SET first_name='$first_name', last_name='$last_name' WHERE id='$id'";
    $result = mysqli_query($conn, $sql);

    if ($result) {
      $msg = "<div class='alert alert-success'>Profile Updated Successfull.</div> <script>window.location.replace('logout.php');</script>";
    }else {
      echo "Error: " . $sql . mysqli_error($conn);
    }
  }
?>

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800">Profile</h1>

    <?php
      if (isset($_POST['submit'])) {
        echo $msg;
      }

      $sql = "SELECT * FROM users WHERE id='$id'";
      $result = mysqli_query($conn, $sql);

      if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
    ?>
    <form class="form" action="" method="post">
      <div class="row">
        <div class="form-group col-sm-6 mb-2">
          <input type="text" name="first_name" placeholder="First Name" class="form-control" value="<?php echo $row['first_name'] ?>" required>
        </div>
        <div class="form-group col-sm-6 mb-2">
          <input type="text" name="last_name" placeholder="Last Name" class="form-control" value="<?php echo $row['last_name'] ?>" required>
        </div>
      </div>
      <div class="row mb-2">
        <div class="form-group col-sm-12 mb-2">
          <input type="email" name="email" class="form-control" value="<?php echo $row['email'] ?>" disabled>
        </div>
      </div>
      <div class="row">
        <div class="col-sm-12">
          <button type="submit" name="submit" class="btn btn-primary">Update Profile</button>
        </div>
      </div>
    </form>
  <?php } ?>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<?php include 'includes/footer.php'; ?>
